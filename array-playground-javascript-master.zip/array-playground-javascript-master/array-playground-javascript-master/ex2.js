/**
 * Recorrer arrays
 * 
 * Una actividad muy común en programación es recorrer los arrays en busca de un elemento
 * 
 * Añade un condicional if... que compruebe si, la variable "siguiente_pez" es "Nemo". Si es "Nemo" muestra por el terminal un mensaje: "He encontrado a Nemo!". Cada vez que no encuentre el pez Nemo, escribe "Este pez NO es Nemo!"
 *
 * Tu código debería escribir un total de 4 mensajes. 
 */

let muchos_peces = ["Dory", "Nemo", "Shipho", "Estrella"]

for(let i=0; i<muchos_peces.length; i++) {
    let siguiente_pez = muchos_peces[i]
    console.log("Pez siguiente: " + siguiente_pez)

    // Modifica aquí
    if(siguiente_pez == muchos_peces[1]){
        console.log("!!!!!! He encontrado a " + siguiente_pez + " !!!!!!")
    }
    else{
        console.log("Este pez no es Nemo")
    }
}



